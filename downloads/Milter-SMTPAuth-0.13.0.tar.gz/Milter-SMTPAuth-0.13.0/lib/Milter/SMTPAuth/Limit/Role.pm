
package Milter::SMTPAuth::Limit::Role;

use Moose::Role;
requires 'get_weight', 'load_config';

1;

