package Milter::SMTPAuth::AccessDB::Role;

use Moose::Role;
requires 'is_reject';

1;

