# -*- coding: utf-8 mode:cperl -*-

package Milter::SMTPAuth::Logger::Formatter;

use Moose::Role;
requires 'output';

1;
